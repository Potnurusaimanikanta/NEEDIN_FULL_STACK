export const homeCarouselData=[
    {
        image:"https://digipanoramic.com/wp-content/uploads/2021/06/advertising.jpeg",
        path:"/women/clothing/lengha_choli"
    },
    {
        image:"https://riyafab.com/cdn/shop/files/Banner_2_f3c53267-0841-4551-94d7-2101c6e3ff48.jpg?v=1687237074&width=1800",
        path:"/women/clothing/women_dress"
    },
    {
        image:"https://www.ethnicplus.in/media/mageplaza/bannerslider/banner/image/9/_/9_8.jpg",
        path:"/women/clothing/women_dress"
    },
    {
        image:"https://www.ethnicplus.in/media/mageplaza/bannerslider/banner/image/1/1/11_4.jpg",
        path:"/women/clothing/women_saree"
    }

]

