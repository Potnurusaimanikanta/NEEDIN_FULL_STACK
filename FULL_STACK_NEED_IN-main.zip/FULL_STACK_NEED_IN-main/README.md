# Must install these Libraries for Frontend 

1. npm i @mui/icons-material
2. npm i react-dom
3. npm i react-redux
4. npm i react-router-dom
5. npm i react-scripts
6. npm i redux-thunk
7. npm i web-vitals

# For Running the application 
1. Setup the database name in the backend file
2. run  the spring boot app

3. And run the developemnt server in react using the command -> npm start

