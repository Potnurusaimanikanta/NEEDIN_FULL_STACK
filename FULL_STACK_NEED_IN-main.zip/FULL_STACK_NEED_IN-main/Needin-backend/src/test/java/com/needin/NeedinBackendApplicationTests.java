package com.needin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeedinBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
