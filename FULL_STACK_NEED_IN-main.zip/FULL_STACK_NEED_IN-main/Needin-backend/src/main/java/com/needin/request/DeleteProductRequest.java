package com.needin.request;

public class DeleteProductRequest {
	
//	private Long 

}
