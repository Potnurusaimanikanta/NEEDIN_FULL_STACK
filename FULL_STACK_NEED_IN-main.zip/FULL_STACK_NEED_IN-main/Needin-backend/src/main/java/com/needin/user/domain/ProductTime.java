package com.needin.user.domain;

public enum ProductTime {

	 	Nine,
	    Ten,
	    Twelve,
	    Two,
	    Four,
//	    XXL,
//	    XXXL,
	    six
}
