package com.needin.user.domain;

public enum PaymentStatus {

	PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
