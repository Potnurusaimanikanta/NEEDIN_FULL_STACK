package com.needin.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
