package com.needin.response;

public class CreatePaymentLinkResponse {
	
	

}
