package com.needin.config;



public class JwtConstant {
	public static final String SECRET_KEY="buhdshfagzgftyafklmweklrucxnebiuysbewgrrwyughjvwerlkjoisidejeje";
	public static final String JWT_HEADER="Authorization";
}
